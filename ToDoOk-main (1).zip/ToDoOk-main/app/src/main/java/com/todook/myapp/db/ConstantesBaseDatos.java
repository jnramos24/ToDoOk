package com.todook.myapp.db;

public class ConstantesBaseDatos {

    public static final String TABLE_TASKS           = "task";
    public static final String TABLE_TASKS_ID        = "id";
    public static final String TABLE_TASKS_NAME    = "taskname";
    public static final String TABLE_TASKS_TASKDATE  = "taskdate";
    public static final String TABLE_TASKS_TIMEDATE     = "timedate";
    public static final String TABLE_TASKS_TYPE      = "type";

}
